# Change log

## 0.3 - 26 August 2026

- Published the YAML artefacts as usable files and made those files the source
  of the PDF listings.
- Added stable identity and schemas for the evidence envelope, change
  mechanics, and validation rule set.
- Generalised evidence joins around `process_cycle_id`, with explicit renewal
  bindings to `renewal_cycle_id` and `policy_id`.
- Changed the core validation rule set to 2.0.0 because V010, V016, and V019
  changed meaning.
- Added V021 through V025 and warning rules W001 through W004.
- Moved model-evaluation and process-definition schemas to 2.0.0 so threshold
  direction and structured transition publication are enforceable.
- Added maturity support to the evaluation, charter, and drift schemas.
- Added process-to-contract and charter-to-process linkage checks.
- Allowed a drift finding to record an `evidence_gap` when neither running
  behaviour nor a production sample can yet be established.
- Clarified drift-report identity and version changes.
- Added four broken fixtures. Three fail as expected; one known institutional
  resolution gap remains open by design.
- Added rule-set, schema-version, and canonical validation-archive provenance
  to the validation record. The PDF carries the distribution archive digest.
- Clarified why portable and renewal-domain keys are emitted together, and
  limited `maturity.mandatory_now` to obligations beyond schema conformance.

Validation result: eight schema contracts and eleven governed artefacts passed
schema validation; no error rule failed; W003 warned on two overdue worked
findings; V023 and W004 were not applicable to the supplied packet.
